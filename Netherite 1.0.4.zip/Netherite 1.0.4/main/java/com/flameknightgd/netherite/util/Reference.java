package com.flameknightgd.netherite.util;

public class Reference 
{
	public static final String MOD_ID = "netherite";
	public static final String NAME = "Netherite";
	public static final String VERSION = "1.0.4";
	public static final String CLIENT_PROXY_CLASS = "com.flameknightgd.netherite.proxy.ClientProxy";
	public static final String COMMON_PROXY_CLASS = "com.flameknightgd.netherite.proxy.CommonProxy";
}