package com.flameknightgd.netherite.util;

public interface IHasModel 
{
	public void registerModels();
}